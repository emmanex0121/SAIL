# A clone of the [google](https://www.google.com) homepage

SAIL tech weekly assesment

### Emmanuel NWachukwu [Github](https://github.com/emmanex0121) / [X](https://twitter.com/PHXKHEED) / [E-mail](emmax0121@gmail.com)
