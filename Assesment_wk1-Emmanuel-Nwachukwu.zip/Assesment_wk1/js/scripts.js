document.addEventListener('DOMContentLoaded', function () {
    console.log("hello world");
});